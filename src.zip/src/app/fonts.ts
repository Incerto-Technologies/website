import { Manrope } from "next/font/google";
// import localFont from "next/font/local";

export const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
});

// export const gotham = localFont({
//   src: [
//     {
//       path: "../../public/fonts/Gotham-Medium.woff2",
//     },
//   ],
//   variable: "--font-gotham",
// });
