export const navRoutes = [
  {
    name: "About us",
    path: "/",
  },
  {
    name: "Blogs",
    path: "/",
  },
  {
    name: "Contact us",
    path: "/",
  },
];
